      <!-- Sidebar -->
      <div class="adminx-sidebar expand-hover push bg-white">
          <ul class="sidebar-nav">
              <li class="sidebar-nav-item">
                  <a href="{{ url('showappointment') }}" class="sidebar-nav-link active">
                      <span class="sidebar-nav-icon">
                          <i data-feather="calendar"></i>
                      </span>
                      <span class="sidebar-nav-name">
                          Appointments
                      </span>
                      <span class="sidebar-nav-end">
                      </span>
                  </a>
              </li>
              <li class="sidebar-nav-item">
                  <a href="{{ url('add_team_view') }}" class="sidebar-nav-link active">
                      <span class="sidebar-nav-icon">
                          <i data-feather="edit"></i>
                      </span>
                      <span class="sidebar-nav-name">
                          Add Kapster
                      </span>
                      <span class="sidebar-nav-end">
                      </span>
                  </a>
              </li>
              <li class="sidebar-nav-item">
                  <a href="{{ url('showteam') }}" class="sidebar-nav-link active">
                      <span class="sidebar-nav-icon">
                          <i data-feather="users"></i>
                      </span>
                      <span class="sidebar-nav-name">
                          Kapster
                      </span>
                      <span class="sidebar-nav-end">
                      </span>
                  </a>
              </li>
          </ul>
      </div><!-- Sidebar End -->
