<!DOCTYPE html>
<html lang="en">
@include('admin.css')

<body>
    <div class="adminx-container">
        @include('admin.navbar')


        @include('admin.sidebar')

        <div class="adminx-content">

            <h1 align="center">SOON</h1>

        </div>
    </div>
    @include('admin.js')
</body>

</html>
