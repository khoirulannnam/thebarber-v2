<nav class="navbar navbar-expand justify-content-between fixed-top bg-white">
    <a class="navbar-brand mb-0 h1 d-none d-md-block" href="{{url('home')}}">
      The Barbers
    </a>

    <x-app-layout>
    </x-app-layout>
  </nav>
