<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="copyright" content="MACode ID, https://macodeid.com/">

    <title>The Barber</title>

    <link rel="stylesheet" href="../assets/css/maicons.css">

    <link rel="stylesheet" href="../assets/css/bootstrap.css">

    <link rel="stylesheet" href="../assets/vendor/owl-carousel/css/owl.carousel.css">

    <link rel="stylesheet" href="../assets/vendor/animate/animate.css">

    <link rel="stylesheet" href="../assets/css/theme.css">

</head>
<style>
    html {
        scroll-behavior: smooth;
    }
</style>

<body>

    <!-- Back to top button -->
    <div class="back-to-top"></div>

    <header>


      <nav class="navbar navbar-expand-lg bg-white shadow-sm fixed-top">
          <div class="container">
              <a class="navbar-brand" href="<?php echo e(url('home')); ?>"><span class="text-primary">The-Barber</span></a>


              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupport"
                  aria-controls="navbarSupport" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupport">
                  <ul class="navbar-nav ml-auto">
                      <li class="nav-item">
                          <a class="nav-link" href="#aboutus">About Us</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="#service">Service</a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="#ourteams">Our Teams</a>
                      </li>

                      <?php if(Route::has('login')): ?>
                          <?php if(auth()->guard()->check()): ?>

                              <li class="nav-item">
                                  <a class="nav-link" href="#appointment">Book</a>
                              </li>

                              <li class="nav-item">
                                  <a class="nav-link" href="<?php echo e(url('myappointment')); ?>">My Appointment</a>
                              </li>

                              <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                               <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
                          <?php else: ?>
                              <li class="nav-item">
                                  <a class="btn btn-primary ml-lg-3" href="<?php echo e(route('login')); ?>">Login / Register</a>
                              </li>

                          <?php endif; ?>
                      <?php endif; ?>
                  </ul>
              </div> <!-- .navbar-collapse -->
          </div> <!-- .container -->
      </nav>
  </header>

    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert">x</button>
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>

    <div class="page-hero bg-image overlay-dark" style="background-image: url(../assets/img/bg_image.jpg);">
        <div class="hero-section">
            <div class="container text-center wow zoomIn">
                <span class="subhead">Let's make your hair look good</span>
                <h1 class="display-4">DARE TO BE DIFFERENT</h1>
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('book')); ?>" class="btn btn-primary">BOOK</a>
                    <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">BOOK</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>


    </div> <!-- .bg-light -->

    <?php echo $__env->make('user.aboutus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.service', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.ourteams', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <script src="../assets/js/jquery-3.5.1.min.js"></script>

    <script src="../assets/js/bootstrap.bundle.min.js"></script>

    <script src="../assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>

    <script src="../assets/vendor/wow/wow.min.js"></script>

    <script src="../assets/js/theme.js"></script>

</body>

</html>
<?php /**PATH C:\laragon\www\thebarber\resources\views/user/home.blade.php ENDPATH**/ ?>