<div class="page-section" id="service">
    <div class="container">
        <h1 class="text-center wow fadeInUp display-4">Service</h1>
        <div class="row mt-5">
            <div class="col-lg-4 py-2 wow zoomIn">
                <div>
                    <div class="header">
                        <img src="../assets/img/service/hair_cut.png" alt="">
                    </div>
                    <div class="body">
                        <h5 class="text-center">Hair Cut</a></h5>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 py-2 wow zoomIn">
                <div>
                    <div class="header">
                        <img src="../assets/img/service/hair_care.png" alt="">
                    </div>
                    <div class="body">
                        <h5 class="text-center">Hair Care</a></h5>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 py-2 wow zoomIn">
                <div>
                    <div class="header">
                        <img src="../assets/img/service/hair_color.png" alt="">
                    </div>
                    <div class="body">
                        <h5 class="text-center">Hair Color</a></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> <!-- .page-section -->
<?php /**PATH C:\laragon\www\thebarber\resources\views/user/service.blade.php ENDPATH**/ ?>