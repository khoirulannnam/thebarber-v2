<div class="page-section pb-0 bg-light" id="aboutus">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 py-3 wow fadeInUp">
                <h1 class="lead">The Barber</h1>
                <p class="text-grey mb-4">Merupakan tempat cukur rambut yang mempunyai konsep menggabungkan antara
                    barbershop dan salon. Ini lah kami yang peduli dengan kualitas hasil potongan rambut untuk para
                    customer kami. Rambut adalah kanvas kami untuk membuat sebuah karya.</p>
            </div>
            <div class="col-lg-6 wow fadeInRight" data-wow-delay="400ms">
                <div class="img-place custom-img-1">
                    <img src="../assets/img/person/person.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div> <!-- .bg-light -->
<?php /**PATH C:\laragon\www\thebarber\resources\views/user/aboutus.blade.php ENDPATH**/ ?>